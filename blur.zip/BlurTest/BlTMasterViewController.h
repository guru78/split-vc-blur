//
//  BlTMasterViewController.h
//  BlurTest
//
//  Created by Matthew Wymore on 9/17/13.
//  Copyright (c) 2013 Haywoodsoft LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BlTDetailViewController;

@interface BlTMasterViewController : UITableViewController

@property (strong, nonatomic) BlTDetailViewController *detailViewController;

- (void) configureLandscapeTable;
- (void) configurePortraitTable;

@end
